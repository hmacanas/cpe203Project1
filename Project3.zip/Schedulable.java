public interface Schedulable {
    void scheduleAllEvents(EventScheduler scheduler, WorldModel world, ImageStore imageStore);
}
