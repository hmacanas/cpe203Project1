interface ExecuteActivity {
    void executeActivity();
}
