interface ActivityEntity extends Entity {
}
