interface AnimationEntity extends Entity
{
    void createAnimationAction();
    int getAnimationPeriod();
}
